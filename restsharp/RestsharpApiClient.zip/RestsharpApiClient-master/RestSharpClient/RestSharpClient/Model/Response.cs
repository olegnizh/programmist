﻿namespace RestSharpClient.Model
{
    public class Response
    {
        public bool Result { get; set; }
        public string Message { get; set; }
    }
}
