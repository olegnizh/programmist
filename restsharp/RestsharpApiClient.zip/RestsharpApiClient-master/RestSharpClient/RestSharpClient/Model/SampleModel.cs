﻿namespace RestSharpClient.Model
{
    public class SampleModel
    {
        public string Value { get; set; }
    }
}
