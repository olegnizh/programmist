﻿namespace JsonExampleProject1
{
	class Pet
	{
		public string Type { get; set; }

		public string Name { get; set; }

		public double Age { get; set; }
	}
}
