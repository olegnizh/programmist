using System.Text.Json;
using RestSharp;


namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string Get_A()
        {
			var pets = new List<Pet>
			{
				new Pet { Type = "Cat", Name = "MooMoo", Age = 3.4 },
				new Pet { Type = "Squirrel", Name = "Sandy", Age = 7}
			};

			var person = new Person
			{
				Name = "John",
				Age = 34,
				StateOfOrigin = "England",
				Pets = pets
			};

			var options = new JsonSerializerOptions
			{
				WriteIndented = true
			};

			return JsonSerializer.Serialize(person, options);

		}

        private void button1_Click(object sender, EventArgs e)
        {
			// serialize
			this.textBox1.Text = Get_A();

        }

        private void button2_Click(object sender, EventArgs e)
        {
			// deserialize

			var client = new RestClient("http://localhost:3000");
			var request = new RestRequest("person");
			var response = client.Execute(request);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                string? rawResponse = response.Content;
                Person? result = JsonSerializer.Deserialize<Person>(rawResponse);
                MessageBox.Show(result.Name.ToString());
                this.listBox1.Items.Clear();
                foreach (Pet p in result.Pets)
                {
                    this.listBox1.Items.Add(p.Name.ToString() + " - " +p.Type.ToString());

                }
            }
            else
            {
                MessageBox.Show("��� ��������� ������ ��������� ������ - " + response.StatusCode);

            }
        }


    }
}