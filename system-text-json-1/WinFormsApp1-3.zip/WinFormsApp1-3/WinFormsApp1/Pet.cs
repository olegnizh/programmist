﻿using System.Text.Json.Serialization;

namespace WinFormsApp1
{
	public class Pet
	{
		public string Type { get; set; }

		public string Name { get; set; }

		[JsonIgnore]
		public double Age { get; set; }
	}
}
