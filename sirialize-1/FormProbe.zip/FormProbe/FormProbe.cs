﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
//using RestSharp;
using System.Net;
using System.Net.Http;


namespace winapp2
{

    public partial class FormProbe : Form
    {

        List<Book> books;

        string sess_id = "";
        int error_code = 0;
        string error_msg = "";


        //private static DatumPerson[] personecp;


        public FormProbe()
        {
            InitializeComponent();

            // Books example
            books = new List<Book>();
            Book book1 = new Book
            {
                title = "Beginning C# and .NET",
                author = "Benjamin Perkins and Jon Reid",
                code = "978-1119795780"
            };
            Book book2 = new Book
            {
                title = "Beginning XML",
                author = "Joe Fawcett et al",
                code = "978-1118162132"
            };
            Book book3 = new Book
            {
                title = "Professional C# 7 and .NET Core",
                author = "Christian Nagel",
                code = "978-1119449270"
            };
            books.Add(book1);
            books.Add(book2);
            books.Add(book3);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            // serialize
            //string jsonString1 = JsonSerializer.Serialize(this.books, typeof(List<Book>));
            string jsonString1 = JsonConvert.SerializeObject(books);
            File.WriteAllText("Books.json", jsonString1);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // deserialize book           
            string jsonString2 = File.ReadAllText("Books.json");
            //List<Book> books2 = JsonSerializer.Deserialize<List<Book>>(jsonString2);
            List<Book> books2 = JsonConvert.DeserializeObject<List<Book>>(jsonString2);

            this.listBox1.Items.Clear();
            foreach (Book b in books2)
            {

                this.listBox1.Items.Add(b.code.ToString() + " - " + b.title.ToString() + " - " + b.author.ToString());
                //Console.WriteLine("code: {0} title: {1} author: {2}", b.code, b.title, b.author);
            }

        }



        private void button6_Click(object sender, EventArgs e)
        {
            // ecp login
            //string rawresponse = Info.get_response_loginecp("Ttttt_smp", "P@ssw0rd333");
            //if (rawresponse == "") return;
            //LoginEcp result = JsonConvert.DeserializeObject<LoginEcp>(rawresponse);
            //this.sess_id = result.sess_id;
            //this.error_code = result.error_code;

            //this.textBox1.Text = this.error_code.ToString();
            //this.textBox2.Text = this.sess_id.ToString();

            //Info.sess_id = this.sess_id.ToString();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            // other


        }



        private void button3_Click(object sender, EventArgs e)
        {
            FormMenu f = new FormMenu();
            this.Hide();
            f.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Employees json-server
            /*
            Employees employees = new Employees
            {
                id = Convert.ToInt32(this.textBox3.Text.ToString()),
                name = this.textBox4.Text.ToString(),
                salary = this.textBox5.Text.ToString()
            };
            string jsonBody = JsonConvert.SerializeObject(employees);
            //MessageBox.Show(jsonBody);

            var client = new RestClient("http://localhost:3000");
            var request = new RestRequest("employees");
            request.Method = Method.POST;
            request.AddJsonBody(jsonBody);
            var response = client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                ;

            }
            else MessageBox.Show("response-StatusCode = " + response.StatusCode.ToString());
            */
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // make men in ecp
           /*
            var client = new RestClient("https://testecp.mznn.ru/api");
            //var request = new RestRequest("Person").AddJsonBody(person);
            var request = new RestRequest("Person");
            request.Method = Method.POST;
            request.RequestFormat = DataFormat.Json;            
            request.AddJsonBody(this.textBox7.Text.ToString());

            var response = client.Execute(request);
            this.textBox8.Text = response.Content;

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                string rawResponse = response.Content;
                
                PersonCreated result = JsonConvert.DeserializeObject<PersonCreated>(rawResponse);

                MessageBox.Show("create person err " + result.error_code.ToString());
                MessageBox.Show("create person id " + result.data[0]);

            }
            else MessageBox.Show("response-StatusCode = " + response.StatusCode.ToString());

           */
        }

        private void button8_Click(object sender, EventArgs e)
        {
            /*
            // https://jasonwatmore.com/c-restsharp-http-post-request-examples-in-net
            var client = new RestClient("https://testapi.jasonwatmore.com");
            var request = new RestRequest("products");
            request.Method = Method.POST;
            request.AddJsonBody(new
            {
                name = "RestSharp POST Request Example"
            });

            var response = client.Execute(request);
            //var response = client.ExecuteAsPost(request, "POST");
            //MessageBox.Show(response.Content.ToString());
            this.textBox8.Text = response.Content.ToString();

            //var response = client.ExecuteAsPost(request, "POST");
            //var response = client.ExecutePost(request);

            //MessageBox.Show(response.Content.ToString());

            // deserialize json string response to JsonNode object
            //var data = JsonSerializer.Deserialize<JsonNode>(response.Content!)!;
            */

        }

        private void button9_Click(object sender, EventArgs e)
        {

            PersonCreate person = new PersonCreate
            {
                PersonSurName_SurName = this.tb_fam.Text.ToString().Trim(),
                PersonBirthDay_BirthDay = "2011-09-09",
                Person_Sex_id = 1,
                SocStatus_id = 1,
                sess_id = this.textBox2.Text.ToString()
            };

            string jsonBody = JsonConvert.SerializeObject(person);
            this.textBox7.Text = jsonBody;

        }


        private void button10_Click(object sender, EventArgs e)
        {
            // get person
            string rawresponse = "";
            /*
            var client1 = new RestClient("https://testecp.mznn.ru/api");
            var request1 = new RestRequest("Person");
            request1.Method = Method.GET;
            request1.AddParameter("PersonSurName_SurName", "Нижегородов");
            //request1.AddParameter("PersonFirName_FirName", "");
            request1.AddParameter("PersonBirthDay_BirthDay", "1966-02-25");
            //request1.AddParameter("PersonSnils_Snils", "111 111 111 11");
            request1.AddParameter("sess_id", this.sess_id);           
            var response1 = client1.Execute(request1);
            if (response1.StatusCode == System.Net.HttpStatusCode.OK)
            {
                rawresponse = response1.Content;
                PersonGet result2 = JsonConvert.DeserializeObject<PersonGet>(rawresponse);

                //MessageBox.Show("personget err " + result2.error_code.ToString());
                //MessageBox.Show("personget data " + result2.data[1]);
                this.textBox8.Text = rawresponse;

            }
            else MessageBox.Show("personget: response-StatusCode = " + response1.StatusCode.ToString());
            */

        }

        private void button11_Click(object sender, EventArgs e)
        {
            // hhhh
            PersonGet p;

            //public static string get_response_personget(string PersonSurName, string PersonBirthDay, string sessid)
            string rawresp = Info.get_response_personget("Нижегородов", "1966-02-25", Info.sess_id);
            p = JsonConvert.DeserializeObject<PersonGet>(rawresp);
            MessageBox.Show(" error_code = " + p.error_code.ToString());
            MessageBox.Show(" Person_id = " + p.data[0].Person_id.ToString());

        }


    }
    


}
